package bicepbuddy;

import java.io.Serializable;

public class Profile implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5316580046572463031L;

	private String name;

	private Double weight; //pounds
	private int height; //inches
	private Double bmi;
	private Integer age;
	
	private Integer difficulty;
	private Integer workouts; // per week
	private int goal; // scale from 0/weight loss to 100/bulk
	
	int workoutsCompleted;
	int exercisesCompleted;

	public Profile() {
		this.name = "";
		this.weight = 0.0;
		this.height = 0;
		this.age = 0;
		this.difficulty = 0;
		this.workouts = 0;
		this.goal = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int feet, int inches) {
		this.height = (12*feet)+inches;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Integer getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(Integer difficulty) {
		this.difficulty = difficulty;
	}

	public Integer getWorkouts() {
		return workouts;
	}

	public void setWorkouts(Integer workouts) {
		this.workouts = workouts;
	}

	public int getGoal() {
		return goal;
	}

	public void setGoal(int goal) {
		this.goal = goal;
	}

	public Double getBmi() {
		bmi = calculateBmi();
		return bmi;
	}

	public Double calculateBmi() {
		//convert height (inches) to height (centimeters) and square the result
		double heightConverted = Math.pow(this.height, 2);
		//convert weight (pounds) to weight (kilograms)
		double weightConverted = this.weight*703;
		//calculate bmi
		bmi = weightConverted/heightConverted;
		return bmi;
	}
}

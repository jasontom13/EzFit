package bicepbuddy;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exercises.BackExercise;
import exercises.BicepExercise;
import exercises.ChestExercises;
import exercises.LegExercise;
import exercises.ShoulderExercise;
import exercises.TrapsExercise;
import exercises.TricepExercise;

public class Workout implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4365628953453152523L;
	private List<Exercise> exercises;
	private Profile profile;

	public Workout(Profile profile) {
		exercises = new ArrayList<Exercise>();
		this.profile = profile;
	}

	public void add(Exercise e) {
		exercises.add(e);
	}

	// get exercise at top of list
	public Exercise getExercise(Integer i) {
		return exercises.get(i);
	}

	public boolean isEmpty() {
		Boolean isEmpty = false;
		for (Exercise e : exercises)
			isEmpty = isEmpty && e.getDone();
		return isEmpty;
	}

	public List<Exercise> getList() {
		return exercises;
	}

	public List<Exercise> Generator() {

		// What is their goal? (scale 0 to 100/loss to bulk)
		int goal = profile.getGoal();

		// How many per week are they doing? - more dense if fewer
		int daysAWeek = profile.getWorkouts();

		// What difficulty level are they at?
		int difficulty = profile.getDifficulty();

		// Calculate the workout!
		if (daysAWeek == 1) {
			for (int i = 0; i < 6; i++) {
				switch (i) {
				case 0:
					exercises.add(BicepExercise.getBiceps().get(0));
					break;
				case 1:
					exercises.add(BicepExercise.getBiceps().get(0));
					break;
				case 2:
					exercises.add(BicepExercise.getBiceps().get(0));
					break;
				case 3:
					exercises.add(BicepExercise.getBiceps().get(0));
					break;
				case 4:
					exercises.add(BicepExercise.getBiceps().get(0));
					break;
				case 5:
					exercises.add(BicepExercise.getBiceps().get(0));
					break;
				default:
					break;

				}
			}
		}

		return exercises;
	}
}
